create database Product18003959

create table product(
proID varchar(15) primary key not null,
proName varchar(20) not null,
proDesc varchar(50) not null,
proPrice numeric not null,
proCat varchar(20) not null);

create table customer(
custID varchar(15) primary key not null,
custName varchar(20) not null,
custPass varchar(10) not null);

create table employee(
empID varchar(15) primary key not null,
empName varchar(20) not null,
empPadd varchar(10) not null);

create table previousTrans(
prevID varchar(15) primary key not null,
proID varchar(15) foreign key references product(proID),
proName varchar(20) not null,
custID varchar(15) foreign key references customer(custID));

create table orderHistory(
orderID varchar(15) primary key not null,
proID varchar(15) foreign key references product(proID),
numOrders numeric not null);

insert into product VALUES ('12345','productX1','Description of poduct X1',500,'X');
insert into product VALUES ('54321','productX2','Description of poduct X2',1000,'X');
insert into product VALUES ('11111','productY1','Description of poduct Y1',680,'Y');
insert into product VALUES ('22222','productY2','Description of poduct Y2',300,'Y');

insert into customer VALUES ('123','EB','12345');

insert into employee VALUES ('456','Shivr','12345');

insert into previousTrans VALUES ('6542','12345','productX1','123');

insert into orderHistory VALUES ('999','12345',1);
insert into orderHistory VALUES ('998','54321',1);
insert into orderHistory VALUES ('997','11111',1);
insert into orderHistory VALUES ('996','22222',1);

drop table previousTrans;
drop table orderHistory;
drop table product;
drop table customer;
drop table employee;