﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _18003959_POE_CLIENT.Models
{
    public class Employee
    {
        public string EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpPadd { get; set; }
    }
}
