﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _18003959_POE_CLIENT.Models
{
    public class Customer
    {
        public Customer()
        {
            PreviousTrans = new HashSet<PreviousTrans>();
        }

        public string CustId { get; set; }
        public string CustName { get; set; }
        public string CustPass { get; set; }

        public virtual ICollection<PreviousTrans> PreviousTrans { get; set; }
    }
}
