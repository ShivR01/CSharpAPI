﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _18003959_POE_CLIENT.Models
{
    public class Products
    {
        public string ProId { get; set; }
        public string ProName { get; set; }
        public string ProDesc { get; set; }
        public long ProPrice { get; set; }
        public string ProCat { get; set; }
        public object[] OrderHistory { get; set; }
        public object[] PreviousTrans { get; set; }
    }
}
