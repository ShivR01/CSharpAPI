﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _18003959_POE_CLIENT.Models
{
    public class PreviousTrans
    {
        public string PrevId { get; set; }
        public string ProId { get; set; }
        public string ProName { get; set; }
        public string CustId { get; set; }
        public object Cust { get; set; }
        public object Pro { get; set; }
    }
}
