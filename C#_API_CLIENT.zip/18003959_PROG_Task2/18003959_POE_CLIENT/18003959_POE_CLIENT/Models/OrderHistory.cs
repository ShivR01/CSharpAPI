﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _18003959_POE_CLIENT.Models
{
    public class OrderHistory
    {
        public long OrderId { get; set; }

        public long ProId { get; set; }

        public long NumOrders { get; set; }

        public object Pro { get; set; }
    }
}
