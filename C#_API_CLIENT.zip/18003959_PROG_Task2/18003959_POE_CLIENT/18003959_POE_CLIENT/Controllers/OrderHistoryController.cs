﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using _18003959_POE_CLIENT.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace _18003959_POE_CLIENT.Controllers
{
    public class OrderHistoryController : Controller
    {
        string baseUrl = "https://18003959poeapi20200819084428.azurewebsites.net/";

        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderHistory>>> Orders()
        {

            if (HttpContext.Session.GetString("token") != null)
            {
                List<OrderHistory> order = new List<OrderHistory>();

                HttpClient httpClient = new HttpClient();

                using (httpClient)
                {
                    httpClient.BaseAddress = new Uri(baseUrl);
                    httpClient.DefaultRequestHeaders.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", (HttpContext.Session.GetString("token")));

                    HttpResponseMessage responseMessage = await httpClient.GetAsync("api/orderhistories");

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string orderResponse = responseMessage.Content.ReadAsStringAsync().Result;
                        order = JsonConvert.DeserializeObject<List<OrderHistory>>(orderResponse);
                    }
                }
                return View(order);
            }
            else
            {
                return RedirectToAction("Login", "Employee");
            }

        }
    }
}