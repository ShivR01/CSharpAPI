﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using _18003959_POE_CLIENT.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace _18003959_POE_CLIENT.Controllers
{
    public class ProductsController : Controller
    {
        string baseUrl = "https://18003959poeapi20200819084428.azurewebsites.net/";

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Products>>> Index()
        {

            List<Products> products = new List<Products>();

            HttpClient httpClient = new HttpClient();

            using (httpClient)
            {
                httpClient.BaseAddress = new Uri(baseUrl);
                httpClient.DefaultRequestHeaders.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage responseMessage = await httpClient.GetAsync("api/products");

                if (responseMessage.IsSuccessStatusCode)
                {
                    string productResponse = responseMessage.Content.ReadAsStringAsync().Result;
                    products = JsonConvert.DeserializeObject<List<Products>>(productResponse);
                }
            }
            return View(products);

        }

    }
}