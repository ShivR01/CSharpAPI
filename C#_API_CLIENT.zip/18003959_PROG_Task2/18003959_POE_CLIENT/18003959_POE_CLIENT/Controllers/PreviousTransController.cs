﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using _18003959_POE_CLIENT.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace _18003959_POE_CLIENT.Controllers
{
    public class PreviousTransController : Controller
    {
        string baseUrl = "https://18003959poeapi20200819084428.azurewebsites.net/";

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PreviousTrans>>> PrevTrans()
        {
            if (HttpContext.Session.GetString("token") != null)
            {
                List<PreviousTrans> preTrans = new List<PreviousTrans>();

                HttpClient httpClient = new HttpClient();

                using (httpClient)
                {
                    httpClient.BaseAddress = new Uri(baseUrl);
                    httpClient.DefaultRequestHeaders.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", (HttpContext.Session.GetString("token")));

                    HttpResponseMessage responseMessage = await httpClient.GetAsync("api/previousTrans");

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string prevResponse = responseMessage.Content.ReadAsStringAsync().Result;
                        preTrans = JsonConvert.DeserializeObject<List<PreviousTrans>>(prevResponse);
                    }
                }
                return View(preTrans);
            }
            else
            {
                return RedirectToAction("Login", "Customer");
            }

        }

        [HttpGet]
        public ActionResult Create(string proid, string proname)
        {
            if (HttpContext.Session.GetString("token") != null)
            {
                return View();

            }
            else
            {
                return RedirectToAction("Login", "Customer");
            }
        }


        [HttpPost]
        public async Task<ActionResult> CreateAsync(string ProId, string ProName) 
        {
            PreviousTrans i = new PreviousTrans();
            i.PrevId = DateTime.Now.ToString("yyMMddHHmm");
            i.ProId = ProId;
            i.ProName = ProName;
            i.CustId = "123";

            HttpClient httpClient = new HttpClient();

            using (httpClient) 
            {
                httpClient.BaseAddress = new Uri(baseUrl);
                string content = JsonConvert.SerializeObject(i, Formatting.Indented);
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(content);
                ByteArrayContent byteArrayContent = new ByteArrayContent(buffer);

                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", (HttpContext.Session.GetString("token")));

                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("api/previousTrans", byteArrayContent);

                if (httpResponseMessage.IsSuccessStatusCode) 
                {
                    return RedirectToAction("Index","Products");
                }
            }
            return RedirectToAction("Index", "Products");

        }
    }
}