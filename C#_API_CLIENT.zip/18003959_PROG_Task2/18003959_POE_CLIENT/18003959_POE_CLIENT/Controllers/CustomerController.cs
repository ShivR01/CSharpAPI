﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using _18003959_POE_CLIENT.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace _18003959_POE_CLIENT.Controllers
{
    public class CustomerController : Controller
    {
        string baseUrl = "https://18003959poeapi20200819084428.azurewebsites.net/";

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> LoginAsync(string CustName, string CustPass)
        {
            Customer u = new Customer { CustName = CustName, CustPass = CustPass };

            HttpClient httpClient = new HttpClient();
            using (httpClient)
            {
                httpClient.BaseAddress = new Uri(baseUrl);
                string content = JsonConvert.SerializeObject(u, Formatting.Indented);
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(content);
                ByteArrayContent byteArrayContent = new ByteArrayContent(buffer);
                byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("api/Customers", byteArrayContent);

                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    string s = httpResponseMessage.Content.ReadAsStringAsync().Result;
                    HttpContext.Session.SetString("token", s);
                    return RedirectToAction("Index", "Products");
                }
                else
                {
                    return RedirectToAction("Login", "Customer");
                }

            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View();
        }
    }
}