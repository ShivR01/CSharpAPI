﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _18003959_POE_API.Models;
using Microsoft.AspNetCore.Authorization;

namespace _18003959_POE_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PreviousTransController : ControllerBase
    {
        private readonly Product18003959Context _context;

        public PreviousTransController(Product18003959Context context)
        {
            _context = context;
        }

        // GET: api/PreviousTrans
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PreviousTrans>>> GetPreviousTrans()
        {
            return await _context.PreviousTrans.ToListAsync();
        }

        // GET: api/PreviousTrans/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PreviousTrans>> GetPreviousTrans(string id)
        {
            var previousTrans = await _context.PreviousTrans.FindAsync(id);

            if (previousTrans == null)
            {
                return NotFound();
            }

            return previousTrans;
        }

        // PUT: api/PreviousTrans/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPreviousTrans(string id, PreviousTrans previousTrans)
        {
            if (id != previousTrans.PrevId)
            {
                return BadRequest();
            }

            _context.Entry(previousTrans).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PreviousTransExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PreviousTrans
        [HttpPost]
        public async Task<ActionResult<PreviousTrans>> PostPreviousTrans(PreviousTrans previousTrans)
        {
            _context.PreviousTrans.Add(previousTrans);
            //_context.OrderHistory.Add(new OrderHistory() { NumOrders = +1});
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (PreviousTransExists(previousTrans.PrevId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetPreviousTrans", new { id = previousTrans.PrevId }, previousTrans);
        }

        // DELETE: api/PreviousTrans/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<PreviousTrans>> DeletePreviousTrans(string id)
        {
            var previousTrans = await _context.PreviousTrans.FindAsync(id);
            if (previousTrans == null)
            {
                return NotFound();
            }

            _context.PreviousTrans.Remove(previousTrans);
            await _context.SaveChangesAsync();

            return previousTrans;
        }

        private bool PreviousTransExists(string id)
        {
            return _context.PreviousTrans.Any(e => e.PrevId == id);
        }
    }
}
