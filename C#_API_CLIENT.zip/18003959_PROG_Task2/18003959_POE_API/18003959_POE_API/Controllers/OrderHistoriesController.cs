﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _18003959_POE_API.Models;
using Microsoft.AspNetCore.Authorization;

namespace _18003959_POE_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class OrderHistoriesController : ControllerBase
    {
        private readonly Product18003959Context _context;

        public OrderHistoriesController(Product18003959Context context)
        {
            _context = context;
        }

        // GET: api/OrderHistories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderHistory>>> GetOrderHistory()
        {
            return await _context.OrderHistory.ToListAsync();
        }

        // GET: api/OrderHistories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderHistory>> GetOrderHistory(string id)
        {
            var orderHistory = await _context.OrderHistory.FindAsync(id);

            if (orderHistory == null)
            {
                return NotFound();
            }

            return orderHistory;
        }

        // PUT: api/OrderHistories/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderHistory(string id, OrderHistory orderHistory)
        {
            if (id != orderHistory.OrderId)
            {
                return BadRequest();
            }

            _context.Entry(orderHistory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderHistoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OrderHistories
        [HttpPost]
        public async Task<ActionResult<OrderHistory>> PostOrderHistory(OrderHistory orderHistory)
        {
            _context.OrderHistory.Add(orderHistory);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OrderHistoryExists(orderHistory.OrderId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOrderHistory", new { id = orderHistory.OrderId }, orderHistory);
        }

        // DELETE: api/OrderHistories/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<OrderHistory>> DeleteOrderHistory(string id)
        {
            var orderHistory = await _context.OrderHistory.FindAsync(id);
            if (orderHistory == null)
            {
                return NotFound();
            }

            _context.OrderHistory.Remove(orderHistory);
            await _context.SaveChangesAsync();

            return orderHistory;
        }

        private bool OrderHistoryExists(string id)
        {
            return _context.OrderHistory.Any(e => e.OrderId == id);
        }
    }
}
