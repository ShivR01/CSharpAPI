﻿using System;
using System.Collections.Generic;

namespace _18003959_POE_API.Models
{
    public partial class OrderHistory
    {
        public string OrderId { get; set; }
        public string ProId { get; set; }
        public decimal NumOrders { get; set; }

        public virtual Product Pro { get; set; }
    }
}
