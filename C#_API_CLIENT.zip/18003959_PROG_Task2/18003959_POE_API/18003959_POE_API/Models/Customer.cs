﻿using System;
using System.Collections.Generic;

namespace _18003959_POE_API.Models
{
    public partial class Customer
    {
        public Customer()
        {
            PreviousTrans = new HashSet<PreviousTrans>();
        }

        public string CustId { get; set; }
        public string CustName { get; set; }
        public string CustPass { get; set; }

        public virtual ICollection<PreviousTrans> PreviousTrans { get; set; }
    }
}
