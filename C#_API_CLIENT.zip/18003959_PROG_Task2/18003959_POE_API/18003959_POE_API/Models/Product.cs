﻿using System;
using System.Collections.Generic;

namespace _18003959_POE_API.Models
{
    public partial class Product
    {
        public Product()
        {
            OrderHistory = new HashSet<OrderHistory>();
            PreviousTrans = new HashSet<PreviousTrans>();
        }

        public string ProId { get; set; }
        public string ProName { get; set; }
        public string ProDesc { get; set; }
        public decimal ProPrice { get; set; }
        public string ProCat { get; set; }

        public virtual ICollection<OrderHistory> OrderHistory { get; set; }
        public virtual ICollection<PreviousTrans> PreviousTrans { get; set; }
    }
}
