﻿using System;
using System.Collections.Generic;

namespace _18003959_POE_API.Models
{
    public partial class PreviousTrans
    {
        public string PrevId { get; set; }
        public string ProId { get; set; }
        public string ProName { get; set; }
        public string CustId { get; set; }

        public virtual Customer Cust { get; set; }
        public virtual Product Pro { get; set; }
    }
}
