﻿using System;
using System.Collections.Generic;

namespace _18003959_POE_API.Models
{
    public partial class Employee
    {
        public string EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpPadd { get; set; }
    }
}
