﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace _18003959_POE_API.Models
{
    public partial class Product18003959Context : DbContext
    {
        public Product18003959Context()
        {
        }

        public Product18003959Context(DbContextOptions<Product18003959Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<OrderHistory> OrderHistory { get; set; }
        public virtual DbSet<PreviousTrans> PreviousTrans { get; set; }
        public virtual DbSet<Product> Product { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustId)
                    .HasName("PK__customer__9725F2E644F01947");

                entity.ToTable("customer");

                entity.Property(e => e.CustId)
                    .HasColumnName("custID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CustName)
                    .IsRequired()
                    .HasColumnName("custName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CustPass)
                    .IsRequired()
                    .HasColumnName("custPass")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmpId)
                    .HasName("PK__employee__AFB3EC6DE25C687A");

                entity.ToTable("employee");

                entity.Property(e => e.EmpId)
                    .HasColumnName("empID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.EmpName)
                    .IsRequired()
                    .HasColumnName("empName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EmpPadd)
                    .IsRequired()
                    .HasColumnName("empPadd")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<OrderHistory>(entity =>
            {
                entity.HasKey(e => e.OrderId)
                    .HasName("PK__orderHis__0809337D51679FE5");

                entity.ToTable("orderHistory");

                entity.Property(e => e.OrderId)
                    .HasColumnName("orderID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.NumOrders)
                    .HasColumnName("numOrders")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ProId)
                    .HasColumnName("proID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.Pro)
                    .WithMany(p => p.OrderHistory)
                    .HasForeignKey(d => d.ProId)
                    .HasConstraintName("FK__orderHist__proID__5629CD9C");
            });

            modelBuilder.Entity<PreviousTrans>(entity =>
            {
                entity.HasKey(e => e.PrevId)
                    .HasName("PK__previous__DEFE679229ADDE89");

                entity.ToTable("previousTrans");

                entity.Property(e => e.PrevId)
                    .HasColumnName("prevID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CustId)
                    .HasColumnName("custID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ProId)
                    .HasColumnName("proID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ProName)
                    .IsRequired()
                    .HasColumnName("proName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Cust)
                    .WithMany(p => p.PreviousTrans)
                    .HasForeignKey(d => d.CustId)
                    .HasConstraintName("FK__previousT__custI__5070F446");

                entity.HasOne(d => d.Pro)
                    .WithMany(p => p.PreviousTrans)
                    .HasForeignKey(d => d.ProId)
                    .HasConstraintName("FK__previousT__proID__4F7CD00D");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.ProId)
                    .HasName("PK__product__5BBBEED55515FDCF");

                entity.ToTable("product");

                entity.Property(e => e.ProId)
                    .HasColumnName("proID")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ProCat)
                    .IsRequired()
                    .HasColumnName("proCat")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProDesc)
                    .IsRequired()
                    .HasColumnName("proDesc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProName)
                    .IsRequired()
                    .HasColumnName("proName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProPrice)
                    .HasColumnName("proPrice")
                    .HasColumnType("numeric(18, 0)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
