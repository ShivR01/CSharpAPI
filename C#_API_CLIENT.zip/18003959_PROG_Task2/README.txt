Link to client: https://18003959poeclient20200819085759.azurewebsites.net/

Link to api: https://18003959poeapi20200819084428.azurewebsites.net/api/products
             https://18003959poeapi20200819084428.azurewebsites.net/api/previousTrans (JWT blocks access)
             https://18003959poeapi20200819084428.azurewebsites.net/api/orderhistories (JWT blocks access)

*Customer
    Username: EB
    Password: 12345

*Employee
    Username: Shivr
    Password: 12345