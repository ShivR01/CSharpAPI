﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using ClientCovidAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ClientCovidAPI.Controllers
{
    public class CasesController : Controller
    {
        string baseUrl = "https://api.covid19api.com/";

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CountrySummary>>> Index() 
        {
            List<CountrySummary> countrySummaries = new List<CountrySummary>();

            using (HttpClient client = new HttpClient()) 
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Response = await client.GetAsync("summary");

                if (Response.IsSuccessStatusCode) 
                {
                    string recordsResponse = Response.Content.ReadAsStringAsync().Result;
                    Global g = JsonConvert.DeserializeObject<Global>(recordsResponse);
                    countrySummaries = g.Countries;
                }
            }
            return View(countrySummaries.OrderByDescending(s => s.TotalConfirmed));
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DailyCountryCase>>> GetCases(string id) 
        {
            if (id == null)
            {
                return BadRequest("Error: You need to specify a country!");
            }

            List<DailyCountryCase> records = new List<DailyCountryCase>();

            using (HttpClient client = new HttpClient()) 
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Response = await client.GetAsync("total/country/" + id + "/status/confirmed");

                if (Response.IsSuccessStatusCode)
                {
                    string recordsResponse = Response.Content.ReadAsStringAsync().Result;
                    records = JsonConvert.DeserializeObject<List<DailyCountryCase>>(recordsResponse);
                }
            }
            return View(records.Where(s => s.Cases > 0));
        }

        [HttpGet]
        public ActionResult FilterByRange(string id) 
        {
            return View((object)id);
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<DailyCountryCase>>> FilterByRange(DateTime start, DateTime end, string id) 
        {
            if (id == null || start == null || end == null) 
            {
                return BadRequest("Error: Details missing!");
            }

            List<DailyCountryCase> records = new List<DailyCountryCase>();

            using (HttpClient client = new HttpClient()) 
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Response = await client.GetAsync("total/country/" + id + "/status/confirmed");

                if (Response.IsSuccessStatusCode)
                {
                    string recordsResponse = Response.Content.ReadAsStringAsync().Result;
                    records = JsonConvert.DeserializeObject<List<DailyCountryCase>>(recordsResponse);
                }
            }
            return View("GetCases", records.Where(s => s.Cases > 0 && (s.Date >= start && s.Date <= end)));
        }
    }
}