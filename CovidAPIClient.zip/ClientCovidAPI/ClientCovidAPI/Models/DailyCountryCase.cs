﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClientCovidAPI.Models
{
    public class DailyCountryCase
    //https://api.covid19api.com/total/country/south-africa/status/confirmed

    {
        public string Country { get; set; }

        public string Province { get; set; }

        public int Lat { get; set; }

        public int Lon { get; set; }

        public DateTime Date { get; set; }

        public int Cases { get; set; }

        public string Status { get; set; }
    }
}
