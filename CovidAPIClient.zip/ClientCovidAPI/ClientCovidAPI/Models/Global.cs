﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClientCovidAPI.Models
{
    public class Global
    //https://api.covid19api.com/summary
    {
        public Global Root { get; set; }
        public List<CountrySummary> Countries { get; set; }
        public DateTime Date { get; set; }
    }
}
