create database Incident;

create table incidents(
incident_id varchar(10) primary key not null,
latitude varchar(20) not null,
longitude varchar(20) not null,
roadname varchar(30) not null,
city varchar(30) not null,
incident_type varchar(30) not null,
priorityLevel varchar(5) not null);

insert into incidents VALUES ('1234567','-29.31455','31.23234','somewhere','durban','bad one','2');

create table userTable(
userID varchar(10) primary key not null,
userName varchar(20) not null,
pass varchar(10) not null,
token varchar(max));

insert into userTable VALUES ('0001','ShivR','12345', null);

