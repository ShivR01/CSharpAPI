﻿using System;
using System.Collections.Generic;

namespace TrafficAPI.Models
{
    public partial class Incidents
    {
        public string IncidentId { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string Roadname { get; set; }
        public string City { get; set; }
        public string IncidentType { get; set; }
        public string PriorityLevel { get; set; }
    }
}
