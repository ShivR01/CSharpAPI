﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace TrafficAPI.Models
{
    public partial class IncidentContext : DbContext
    {
        public IncidentContext()
        {
        }

        public IncidentContext(DbContextOptions<IncidentContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Incidents> Incidents { get; set; }
        public virtual DbSet<UserTable> UserTable { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Incidents>(entity =>
            {
                entity.HasKey(e => e.IncidentId)
                    .HasName("PK__incident__E6C40DA3EA767766");

                entity.ToTable("incidents");

                entity.Property(e => e.IncidentId)
                    .HasColumnName("incident_id")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasColumnName("city")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.IncidentType)
                    .IsRequired()
                    .HasColumnName("incident_type")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Latitude)
                    .IsRequired()
                    .HasColumnName("latitude")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude)
                    .IsRequired()
                    .HasColumnName("longitude")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PriorityLevel)
                    .IsRequired()
                    .HasColumnName("priorityLevel")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Roadname)
                    .IsRequired()
                    .HasColumnName("roadname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserTable>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__userTabl__CB9A1CDFD85FB9C1");

                entity.ToTable("userTable");

                entity.Property(e => e.UserId)
                    .HasColumnName("userID")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Pass)
                    .IsRequired()
                    .HasColumnName("pass")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Token)
                    .HasColumnName("token")
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasColumnName("userName")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
