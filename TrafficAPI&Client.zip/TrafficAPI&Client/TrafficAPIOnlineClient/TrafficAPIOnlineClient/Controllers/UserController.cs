﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TrafficAPIOnlineClient.Models;

namespace TrafficAPIOnlineClient.Controllers
{
    public class UserController : Controller
    {
        string baseUrl = "https://localhost:44387/";

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> LoginAsync(string username, string Pass) 
        {
            UserTable u = new UserTable { UserName = username, Pass = Pass};

            HttpClient httpClient = new HttpClient();
            using (httpClient)
            {
                httpClient.BaseAddress = new Uri(baseUrl);
                string content = JsonConvert.SerializeObject(u, Formatting.Indented);
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(content);
                ByteArrayContent byteArrayContent = new ByteArrayContent(buffer);
                byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("api/UserTable", byteArrayContent);

                if (httpResponseMessage.IsSuccessStatusCode)
                {
                    string s = httpResponseMessage.Content.ReadAsStringAsync().Result;
                    HttpContext.Session.SetString("token", s);
                    return RedirectToAction("Index", "Incident");
                }
                else 
                {
                    return RedirectToAction("Login", "User");
                }

            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View();
        }
    }
}