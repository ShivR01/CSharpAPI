﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TrafficAPIOnlineClient.Models;

namespace TrafficAPIOnlineClient.Controllers
{
    public class IncidentController : Controller
    {
        string baseUrl = "https://localhost:44387/";

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Incident>>> Index()
        {
            if (HttpContext.Session.GetString("token") != null)
            {
                List<Incident> incidents = new List<Incident>();

                HttpClient httpClient = new HttpClient();

                using (httpClient)
                {
                    httpClient.BaseAddress = new Uri(baseUrl);
                    httpClient.DefaultRequestHeaders.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", (HttpContext.Session.GetString("token")));

                    HttpResponseMessage responseMessage = await httpClient.GetAsync("api/incidents");

                    if (responseMessage.IsSuccessStatusCode)
                    {
                        string incidentResponse = responseMessage.Content.ReadAsStringAsync().Result;
                        incidents = JsonConvert.DeserializeObject<List<Incident>>(incidentResponse);
                    }
                }
                return View(incidents);
            }
            else 
            {
                return RedirectToAction("Login", "User");
            }
         
        }

        [HttpGet]
        public ActionResult Create() 
        {
            if (HttpContext.Session.GetString("token") != null)
            {
                return View();

            }
            else 
            {
                return RedirectToAction("Login", "User");
            }
        }

        [HttpPost]
        public async Task<ActionResult> CreateAsync(string latitude, string longitude, string roadname, string city, string incidentType, string priorityLevel) 
        {
            Incident i = new Incident();
            i.incidentId = DateTime.Now.ToString("yyMMddHHmm");
            i.latitude = latitude;
            i.longitude = longitude;
            i.roadname = roadname;
            i.city = city;
            i.incidentType = incidentType;
            i.priorityLevel = priorityLevel;

            HttpClient httpClient = new HttpClient();

            using (httpClient) 
            {
                httpClient.BaseAddress = new Uri(baseUrl);
                string content = JsonConvert.SerializeObject(i, Formatting.Indented);
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(content);
                ByteArrayContent byteArrayContent = new ByteArrayContent(buffer);

                byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", (HttpContext.Session.GetString("token")));

                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("api/incidents", byteArrayContent);

                if (httpResponseMessage.IsSuccessStatusCode) 
                {
                    return RedirectToAction("Index");
                }
            }
            return RedirectToAction("Index");

        }
    }
}