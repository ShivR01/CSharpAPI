﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TrafficAPIOnlineClient.Models
{
    public class Incident
    {
        public string incidentId { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string roadname { get; set; }
        public string city { get; set; }
        public string incidentType { get; set; }
        public string priorityLevel { get; set; }
    }
}
